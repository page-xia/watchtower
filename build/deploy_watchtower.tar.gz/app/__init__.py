"""Intraday watchtower application."""
